These files are used by flappy2.svg
If you like to work on them, please commen here: https://github.com/fossasia/flappy-svg/issues/108
